
package com.zuhlke.spring.files.csv.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zuhlke.spring.files.csv.model.StoreOrder;

public interface StoreOrderRepository extends JpaRepository<StoreOrder, Long> {
}