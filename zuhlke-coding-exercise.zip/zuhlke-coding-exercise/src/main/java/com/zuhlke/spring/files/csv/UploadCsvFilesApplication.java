package com.zuhlke.spring.files.csv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UploadCsvFilesApplication {

	public static void main(String[] args) {

		SpringApplication.run(UploadCsvFilesApplication.class, args);
	}

}
