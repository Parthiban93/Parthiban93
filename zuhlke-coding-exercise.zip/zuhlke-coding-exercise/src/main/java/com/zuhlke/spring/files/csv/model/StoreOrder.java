package com.zuhlke.spring.files.csv.model;

import javax.persistence.*;

@Entity
@Table(name="store_order")
public class StoreOrder {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "order_id", unique = true, nullable = false)
  private String orderId;

  @Column(name = "order_date", nullable = false)
  private String orderDate;

  @Column(name = "ship_date", nullable = false)
  private String shipDate;

  @Column(name = "ship_mode")
  private String shipMode;

  @Column(name = "quantity", nullable = false)
  private int quantity;

  @Column(name = "discount")
  private double discount;

  @Column(name = "profit", nullable = false)
  private double profit;

  @Column(name = "product_id", unique = true, nullable = false)
  private String productId;

  @Column(name = "customer_name", nullable = false)
  private String customerName;

  @Column(name = "category", nullable = false)
  private String category;

  @Column(name = "customer_id", unique = true, nullable = false)
  private String customerId;

  @Column(name = "product_name")
  private String productName;

  public StoreOrder() {
  }

  public StoreOrder(String orderId, String orderDate, String shipDate, String shipMode, int quantity,
                    double discount, double profit, String productId, String customerName, String category,
                    String customerId, String productName) {

    this.orderId = orderId;
    this.orderDate = orderDate;
    this.shipDate = shipDate;
    this.shipMode = shipMode;
    this.quantity = quantity;
    this.discount = discount;
    this.profit = profit;
    this.productId = productId;
    this.customerName = customerName;
    this.category = category;
    this.customerId = customerId;
    this.productName = productName;
  }


  public void setId(Long id) { this.id = id; }

  public void setOrderId(String orderId) {
    this.orderId = orderId;
  }

  public void setOrderDate(String orderDate) {
    this.orderDate = orderDate;
  }

  public void setShipDate(String shipDate) {
    this.shipDate = shipDate;
  }

  public void setShipMode(String shipMode) {
    this.shipMode = shipMode;
  }

  public void setQuantity(int quantity) {
    this.quantity = quantity;
  }

  public void setDiscount(double discount) {
    this.discount = discount;
  }

  public void setProfit(double profit) {
    this.profit = profit;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }

  public void setCustomerName(String customerName) {
    this.customerName = customerName;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public void setCustomerId(String customerId) {
    this.customerId = customerId;
  }

  public void setProductName(String productName) {
    this.productName = productName;
  }

  public Long getId() { return id; }

  public String getOrderId() {
    return orderId;
  }

  public String getOrderDate() {
    return orderDate;
  }

  public String getShipDate() {
    return shipDate;
  }

  public String getShipMode() {
    return shipMode;
  }

  public int getQuantity() {
    return quantity;
  }

  public double getDiscount() {
    return discount;
  }

  public double getProfit() {
    return profit;
  }

  public String getProductId() {
    return productId;
  }

  public String getCustomerName() {
    return customerName;
  }

  public String getCategory() {
    return category;
  }

  public String getCustomerId() {
    return customerId;
  }

  public String getProductName() {
    return productName;
  }


  @Override
  public String toString() {
    return "StoreOrder{" +
            "id=" + id +
            ", orderId=" + orderId +
            ", orderDate=" + orderDate +
            ", shipDate=" + shipDate +
            ", shipMode='" + shipMode +
            ", quantity=" + quantity +
            ", discount=" + discount +
            ", profit=" + profit +
            ", productId='" + productId +
            ", customerName='" + customerName +
            ", category='" + category +
            ", customerId='" + customerId +
            ", productName='" + productName +
            "  } ";
    }
}
